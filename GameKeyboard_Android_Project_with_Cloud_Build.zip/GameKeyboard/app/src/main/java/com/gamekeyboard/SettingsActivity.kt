package com.gamekeyboard

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.widget.*

class SettingsActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("gamekeyboard", MODE_PRIVATE)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 32, 28, 28)
            setBackgroundColor(0xFF101522.toInt())
        }
        fun label(s: String, size: Float = 18f) {
            layout.addView(TextView(this).apply {
                text = s; textSize = size; setTextColor(0xFFFFFFFF.toInt())
                setPadding(0, 12, 0, 12)
            })
        }
        label("🎮 GAMEKEYBOARD", 26f)
        label("Игровая клавиатура для всего телефона")
        val themes = listOf("Neon", "Minecraft Pixel", "Arcade", "Cute", "Ocean")
        label("ТЕМА")
        val spinner = Spinner(this)
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, themes)
        spinner.setSelection(themes.indexOf(prefs.getString("theme", "Neon")).coerceAtLeast(0))
        spinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                prefs.edit().putString("theme", themes[position]).apply()
            }
        }
        layout.addView(spinner)
        val vibration = Switch(this).apply {
            text = "Вибрация при нажатии"; setTextColor(-1)
            isChecked = prefs.getBoolean("vibration", true)
            setOnCheckedChangeListener { _, checked -> prefs.edit().putBoolean("vibration", checked).apply() }
        }
        layout.addView(vibration)
        val sound = Switch(this).apply {
            text = "Звук клавиш"; setTextColor(-1)
            isChecked = prefs.getBoolean("sound", false)
            setOnCheckedChangeListener { _, checked -> prefs.edit().putBoolean("sound", checked).apply() }
        }
        layout.addView(sound)
        label("Анимация нажатия")
        val anim = Spinner(this)
        val anims = listOf("Пружина", "Свечение", "Волна", "Без анимации")
        anim.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, anims)
        anim.setSelection(prefs.getInt("animation", 0))
        anim.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                prefs.edit().putInt("animation", position).apply()
            }
        }
        layout.addView(anim)
        val enable = Button(this).apply {
            text = "Включить GameKeyboard"
            setOnClickListener { startActivity(Intent("android.settings.INPUT_METHOD_SETTINGS")) }
        }
        layout.addView(enable)
        val choose = Button(this).apply {
            text = "Выбрать клавиатуру"
            setOnClickListener {
                (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
            }
        }
        layout.addView(choose)
        label("Подсказка: включи GameKeyboard в настройках экранной клавиатуры, затем выбери её через переключатель клавиатур.", 14f)
        setContentView(ScrollView(this).apply { addView(layout) })
    }
}
