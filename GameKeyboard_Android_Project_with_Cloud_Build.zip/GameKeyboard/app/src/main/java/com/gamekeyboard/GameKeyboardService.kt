package com.gamekeyboard

import android.inputmethodservice.InputMethodService
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.*

class GameKeyboardService : InputMethodService() {
    private var caps = false
    private var symbols = false
    private val prefs by lazy { getSharedPreferences("gamekeyboard", MODE_PRIVATE) }

    override fun onCreateInputView(): View {
        val theme = prefs.getString("theme", "Neon") ?: "Neon"
        val bg = when (theme) {
            "Minecraft Pixel" -> 0xFF263B2B.toInt()
            "Arcade" -> 0xFF21123B.toInt()
            "Cute" -> 0xFF49304A.toInt()
            "Ocean" -> 0xFF123A50.toInt()
            else -> 0xFF101522.toInt()
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(5, 7, 5, 7); setBackgroundColor(bg)
        }
        val toolbar = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        addTool(toolbar, "🎮", "GameKeyboard")
        addTool(toolbar, "📋", "Буфер")
        addTool(toolbar, "⚙", "Настройки")
        root.addView(toolbar)
        val rows = if (symbols) listOf(
            listOf("1","2","3","4","5","6","7","8","9","0"),
            listOf("@","#","$","%","&","-","+","(",")","/"),
            listOf("*","\"","' ",":",";","!","?"),
            listOf("ABC"," ,","🌐","space","⌫","↵")
        ) else listOf(
            listOf("q","w","e","r","t","y","u","i","o","p"),
            listOf("a","s","d","f","g","h","j","k","l"),
            listOf("⇧","z","x","c","v","b","n","m","⌫"),
            listOf("?123",",","🌐","space",".","↵")
        )
        rows.forEachIndexed { index, row ->
            val line = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER
            }
            row.forEach { key ->
                val text = when {
                    key == "space" -> "␣"
                    key == "🌐" -> "🌐"
                    key == "⌫" || key == "↵" || key == "⇧" || key == "?123" || key == "ABC" -> key
                    caps -> key.uppercase()
                    else -> key
                }
                val button = Button(this).apply {
                    this.text = text
                    isAllCaps = false
                    textSize = if (key == "space") 13f else 17f
                    typeface = Typeface.DEFAULT_BOLD
                    setTextColor(Color.WHITE)
                    background = android.graphics.drawable.GradientDrawable().apply {
                        cornerRadius = if (theme == "Minecraft Pixel") 7f else 18f
                        setColor(if (key in listOf("↵","⌫","⇧","?123","ABC")) 0xFF46516B.toInt() else 0xFF283247.toInt())
                        setStroke(1, 0xFF64748B.toInt())
                    }
                    setPadding(0, 0, 0, 0)
                    val weight = if (key == "space") 2.6f else 1f
                    layoutParams = LinearLayout.LayoutParams(0, dp(49), weight).apply {
                        setMargins(dp(2), dp(3), dp(2), dp(3))
                    }
                    setOnClickListener {
                        animateKey(this)
                        if (prefs.getBoolean("vibration", true)) vibrate()
                        handleKey(key)
                    }
                }
                line.addView(button)
            }
            root.addView(line)
        }
        return root
    }

    private fun addTool(row: LinearLayout, icon: String, action: String) {
        val b = TextView(this).apply {
            text = "$icon  $action"; textSize = 13f; setTextColor(Color.WHITE)
            setPadding(dp(8), dp(8), dp(8), dp(8))
            setOnClickListener {
                when (action) {
                    "Буфер" -> showClipboard()
                    "Настройки" -> {
                        val i = packageManager.getLaunchIntentForPackage(packageName)
                        i?.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK); if (i != null) startActivity(i)
                    }
                }
            }
        }
        row.addView(b)
    }

    private fun handleKey(key: String) {
        val ic = currentInputConnection ?: return
        when (key) {
            "⌫" -> ic.deleteSurroundingText(1, 0)
            "↵" -> {
                val action = currentInputEditorInfo?.imeOptions?.and(EditorInfo.IME_MASK_ACTION) ?: EditorInfo.IME_ACTION_NONE
                if (action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED) ic.performEditorAction(action)
                else ic.commitText("\n", 1)
            }
            "⇧" -> { caps = !caps; setInputView(onCreateInputView()) }
            "?123" -> { symbols = true; setInputView(onCreateInputView()) }
            "ABC" -> { symbols = false; setInputView(onCreateInputView()) }
            "space" -> ic.commitText(" ", 1)
            "🌐" -> switchToNextInputMethod(false)
            else -> {
                val value = if (caps) key.uppercase() else key
                ic.commitText(value, 1)
                if (caps) { caps = false; setInputView(onCreateInputView()) }
            }
        }
    }

    private fun showClipboard() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = cm.primaryClip
        val text = if (clip != null && clip.itemCount > 0) clip.getItemAt(0).coerceToText(this).toString() else ""
        if (text.isNotBlank()) {
            currentInputConnection?.commitText(text, 1)
        } else {
            Toast.makeText(this, "Буфер обмена пока пуст", Toast.LENGTH_SHORT).show()
        }
    }

    private fun animateKey(v: View) {
        when (prefs.getInt("animation", 0)) {
            0 -> { v.animate().scaleX(0.90f).scaleY(0.90f).setDuration(65).withEndAction {
                v.animate().scaleX(1f).scaleY(1f).setDuration(100).start()
            }.start() }
            1 -> { v.animate().alpha(0.55f).setDuration(55).withEndAction {
                v.animate().alpha(1f).setDuration(130).start()
            }.start() }
            2 -> { v.animate().translationY(-dp(3).toFloat()).setDuration(55).withEndAction {
                v.animate().translationY(0f).setDuration(120).start()
            }.start() }
        }
    }

    private fun vibrate() {
        val vibrator = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        if (android.os.Build.VERSION.SDK_INT >= 26)
            vibrator.vibrate(VibrationEffect.createOneShot(12, VibrationEffect.DEFAULT_AMPLITUDE))
        else @Suppress("DEPRECATION") vibrator.vibrate(12)
    }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
